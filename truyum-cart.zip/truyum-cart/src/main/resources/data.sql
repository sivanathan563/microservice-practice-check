INSERT INTO users (name) VALUES (
	'Ivan'),
    ('Neil'),
    ('Caffrey');
    

INSERT INTO cart(userid,menuid) VALUES (1,1),(1,2),(2,3);
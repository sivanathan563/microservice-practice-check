DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS cart;

CREATE TABLE users (
	userid int NOT NULL AUTO_INCREMENT,
    name varchar(20),
    primary key(userid)
    );
    
CREATE TABLE cart (
	cartid int NOT NULL AUTO_INCREMENT,
    userid int NOT NULL,
    menuid int NOT NULL,
    primary key(cartid),
    foreign key(userid) references users(userid)
    );
	
package com.cognizant.truyum.service;

import com.cognizant.truyum.model.*;
import com.cognizant.truyum.repository.CartRepository;

import java.util.List;

import javax.transaction.Transactional;

//import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.truyum.dao.CartEmptyException;


@Service
@Transactional
public class CartService {

	@Autowired
	private UserService userService;

	
	@Autowired
	private CartRepository cartRepository;
	
	@Transactional
	public List<Cart> getAllCartItems(long userId) throws CartEmptyException{
		if(!cartRepository.getAllCartItems(userId).isEmpty()) {
			return cartRepository.getAllCartItems(userId);
		}
		else {
			throw new CartEmptyException();
		}
	}
	
	
	@Transactional
	public void addToCart(long userId, long menuItemId) {
		cartRepository.save(new Cart());
	}
	
	
	
	
	
	public void removeCartItem(long userId, long menuItemId){
		cartRepository.deleteByUserAndMenuId(userService.getUser(userId), menuItemId);
	}
	
}

package com.cognizant.truyum.controller;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.cognizant.truyum.dao.CartEmptyException;
import com.cognizant.truyum.model.Cart;
import com.cognizant.truyum.model.MenuItem;
import com.cognizant.truyum.repository.MenuItemFeign;
import com.cognizant.truyum.service.CartService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@EnableEurekaClient
@RestController
@RequestMapping("/carts")
public class CartController {
	
	
	@Autowired
	private CartService cartService;
	
	@Autowired
	private MenuItemFeign feign;
	
	@GetMapping(value = "/{userId}")
	public List<MenuItem> getAllCartItems(@PathVariable long userId) throws CartEmptyException {
		
		List<MenuItem> menuList = new ArrayList<>();
		List<Long> menuIdList = new ArrayList<>();
		cartService.getAllCartItems(userId).stream()
								.forEach(c -> menuIdList.add(c.getMenuId())
				);
		
		menuIdList.stream()
				  .forEach(m -> {System.out.println(m); menuList.add(feign.getMenuItem(m));});
		
		//menuList.add(feign.getMenuItem(1));
		return menuList;
	}
	
	@GetMapping("/")
	public ResponseEntity<String> checkTry(){
		return ResponseEntity.ok().body(feign.aaaaa());
	}
	

	@PostMapping("/{userId}/{menuItemId}")
	public void addCartItem(@PathVariable long userId, @PathVariable long menuItemId) {
		cartService.addToCart(userId, menuItemId);
	}
	
	
	@DeleteMapping("/{userId}/{menuItemId}")
	public void removeCartItem(@PathVariable long userId, @PathVariable long menuItemId) {
		cartService.removeCartItem(userId, menuItemId);
	}
	
}
package com.cognizant.truyum.repository;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

import com.cognizant.truyum.model.MenuItem;

import feign.Headers;

@Headers("Content-Type: application/json")

@FeignClient(name = "menu-service", url = "${MENU_SERVICE:http://localhost:9051/}")
public interface MenuItemFeign {
	
	@GetMapping("/menu-items/")
	String aaaaa();

	@GetMapping(value = "/menu-items/{menuItemId}")//, produces = "application/json")
	MenuItem getMenuItem(@PathVariable long menuItemId);

}

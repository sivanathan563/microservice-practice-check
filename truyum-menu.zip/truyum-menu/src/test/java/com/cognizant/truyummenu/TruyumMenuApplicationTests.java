package com.cognizant.truyummenu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TruyumMenuApplicationTests {

	@Test
	void contextLoads() {
	}

}

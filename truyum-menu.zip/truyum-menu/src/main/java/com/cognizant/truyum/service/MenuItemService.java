package com.cognizant.truyum.service;

import com.cognizant.truyum.model.*;
import com.cognizant.truyum.repository.MenuItemRepository;
import com.cognizant.truyum.util.DateUtil;

import lombok.extern.slf4j.Slf4j;

import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@Transactional
public class MenuItemService {
	
	@Autowired
	private MenuItemRepository menuItemRepository;

	@Transactional
	public List<MenuItem> getMenuItemListAdmin(){
		log.debug("Start: Fetching all menu items for admin.");
		return menuItemRepository.findAll();
	}
	
	@Transactional
	public List<MenuItem> getMenuItemListCustomer(){
		log.debug("Start: Fetching menu items for customer based on \"Active=Yes\" and current date.");
		return menuItemRepository.getMenuItemListCustomer("Yes",new Date());	
	}
	
	@Transactional
	public MenuItem getMenuItem(long menuItemId) {
		log.debug("Start: Fetching menu item for edit form based on menu item id.");
		return menuItemRepository.findById(menuItemId).get();
	}
	
	@Transactional
	public void editMenuItem(MenuItem menuItem) {
		log.debug("Start: Edit menu item based on the edit form values.");
		menuItemRepository.save(menuItem);
		
	}
	
}

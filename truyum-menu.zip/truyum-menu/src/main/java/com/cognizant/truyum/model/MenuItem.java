package com.cognizant.truyum.model;



import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.springframework.format.annotation.DateTimeFormat;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor

@Entity
@Table(name = "menu_item")
public class MenuItem {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "menuid", columnDefinition = "INTEGER")
	private long menuItemId;
	@NotEmpty(message="Title is required.")
	@Size(min=2, max=65, message = "Title should be of 2 to 65 characters.")
	@Pattern(regexp="[a-zA-Z ]+", message = "Title should contain only alphabets and space.")
	@Column(name = "name")
	private String name;
	@NotNull(message="Price is required.")
	@Min(value = 0, message = "Price has to be a positive number.")
	@Max(value = (long)Double.MAX_VALUE, message = "Price has to be a positive number.")
	@Column(name = "price", columnDefinition = "DECIMAL")
	private Double price;
	@Column(name = "active")
	private String active;
	@DateTimeFormat(pattern = "dd-MM-yyyy")
	@NotNull(message="Launch Date is required.")
	@Column(name = "dateoflaunch")
	private Date dateOfLaunch;
	@Column(name = "category")
	private String category;
	@Column(name = "freedelivery")
	private String freeDelivery;
	
	/*
	@OneToMany(mappedBy = "menuItemList")
	private Cart cart;
	*/
	
	
	
	
	

}

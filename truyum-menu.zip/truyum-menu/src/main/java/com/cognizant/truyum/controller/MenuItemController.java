package com.cognizant.truyum.controller;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.cognizant.truyum.model.MenuItem;
import com.cognizant.truyum.service.MenuItemService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@EnableEurekaClient
@RestController

@RequestMapping("/menu-items")
public class MenuItemController {


	@Autowired
	private MenuItemService menuItemService;
	
	@InitBinder
	public void initBinder(WebDataBinder binder) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, false));
	}

	@GetMapping("/")
	public String aaaaa() {
		return "truyum";
	}
	
	
	
	/*
	 * Show Menu List for Admin.
	 * To display the menu list of items for admin.
	 */
	@GetMapping("/show-menu-list-admin")
	public List<MenuItem> showMenuItemListAdmin() {
		log.info("Display menu item list for admin.");
		log.info("End");
		return menuItemService.getMenuItemListAdmin();
	}
	
	/*
	 * Show Menu List for Customer.
	 * To display the menu list of items for customer.
	 */
	@GetMapping("/show-menu-list-customer")
	public List<MenuItem> showMenuItemListCustomer() {
		log.info("Display menu item list for customer.");
		log.info("End");
		return menuItemService.getMenuItemListCustomer();
	}
	
	/*
	 * Get MenuItem by id. 
	 */
	@GetMapping(value = "/{menuItemId}")//, consumes = "application/json")
	public MenuItem getMenuItem(@PathVariable long menuItemId) {
		log.info("Show menu item.");
		log.info("End.");
		return menuItemService.getMenuItem(menuItemId);
	}
	
	
	
	
	/*
	 * Put Mapping for saving MenuItem.
	 */
	@PutMapping("/edit-menu-item")
	public void editMenuItem(@RequestBody MenuItem menuItem) {
		log.info("Add menu item.");
		menuItemService.editMenuItem(menuItem);
		log.info("End.");
	}
	
	
}

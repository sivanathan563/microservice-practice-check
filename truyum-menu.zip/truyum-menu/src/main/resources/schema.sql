DROP TABLE IF EXISTS menu_item;

CREATE TABLE menu_item (
	menuid int NOT NULL,
	name varchar(65) NOT NULL,
	price decimal(6,2) NOT NULL,
	active varchar(3) NOT NULL,
	dateoflaunch date NOT NULL,
	category varchar(20) NOT NULL,
	freedelivery varchar(3) NOT NULL,
	PRIMARY KEY(menuid)
	);
	

	
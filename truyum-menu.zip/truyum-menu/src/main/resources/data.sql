INSERT INTO menu_item VALUES
	(1,'Sandwich', 99.00, 'Yes', '2017-03-15', 'Main Course', 'Yes'),
    (2,'Burger', 129.00, 'Yes', '2017-12-23', 'Main Course', 'No'),
    (3,'Pizza', 149.00, 'Yes', '2017-08-21', 'Main Course', 'No'),
    (4,'French Fries', 57.00, 'No', '2017-07-02', 'Starters', 'Yes'),
    (5,'Chocolate Brownie', 32.00, 'Yes', '2022-11-02', 'Dessert', 'Yes')
    ;

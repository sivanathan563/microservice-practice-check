package com.cognizant.eurekadiscoveryserver1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekaDiscoveryServer1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
